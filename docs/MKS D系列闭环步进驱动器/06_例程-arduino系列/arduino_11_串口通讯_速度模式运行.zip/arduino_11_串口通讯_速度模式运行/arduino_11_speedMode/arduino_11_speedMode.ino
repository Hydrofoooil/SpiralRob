/**************** MKS SERVOxxD闭环步进电机 ***************
******************** arduino系列实验11 ********************
**	实验名称：电机速度模式运行
**  实验目的：通过串口控制电机以速度模式运行
**  实验现象：程序运行后，可观察到
** 1. LED灯亮/灭一次，电机改变一次速度运行，不停循环运行；
** 2. 如果运行失败，LED灯快闪.；
**  注意事项：
** 1. 串口和USB下载口共用串口（0,1），USB上传程序时，先拔掉串口线，以免程序上传失败；
** 2. 电机工作模式设置为SR_vFOC，;
** 3. 如果程序上传失败，可以尝试：按住UNO的RESET按键，再点击上传，待arduino显示“正在上传”时，迅速松开按键；
** 其他资源：
**  CSDN博客：https://blog.csdn.net/gjy_skyblue
**  B站视频：https://space.bilibili.com/393688975/channel/series
**  百度网盘：https://pan.baidu.com/s/1BjrK9SC8pWnDoU32F8jHqA?pwd=mks2
**	QQ技术群：948665794							
**********************************************************/

uint8_t txBuffer[20];      //上位机发送数据数组
uint8_t rxBuffer[20];      //上位机接收数据数组
uint8_t rxCnt=0;          //接收数据计数

uint16_t runSpeed=100;    //电机运行速度
uint8_t runDir  = 1;      //电机运行方向

uint8_t getCheckSum(uint8_t *buffer,uint8_t len);
void speedModeRun(uint8_t slaveAddr,uint8_t dir,uint16_t speed,uint8_t acc);
uint8_t waitingForACK(uint8_t len);

void setup() {
  // 设置LED灯端口为输出
  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, LOW);
  // 启动串口，设置速率38400
  Serial.begin(38400);
  while (!Serial) {
    ; // wait for serial port to connect. Needed for native USB port only
  }
  delay(3000);
}

void loop() {

  uint8_t ackStatus;
  
  speedModeRun(1,runDir,runSpeed,2); //从机地址=1，加速度=2
  digitalWrite(LED_BUILTIN, digitalRead(LED_BUILTIN)^1);
  ackStatus = waitingForACK(5);      //等待电机应答

  if(ackStatus == 1)        //运行成功
  {
    runSpeed += 100;        //速度增加100RPM
    if(runSpeed > 300)     //改变速度和方向
    {
      runSpeed = 0;         //速度设置为0
      runDir ^= 1;          //改变方向
    }
  }
  else                      //运行失败
  {
    while(1)                //闪灯提示运行失败
    {
      digitalWrite(LED_BUILTIN, HIGH);
      delay(200);
      digitalWrite(LED_BUILTIN, LOW);
      delay(200);
    }
  }

  delay(3000);    //延时3000毫秒
}

/*
功能：串口发送速度模式运行指令
输入：slaveAddr 从机地址
      dir       运行方向
      speed     运行速度
      acc       加速度
*/
void speedModeRun(uint8_t slaveAddr,uint8_t dir,uint16_t speed,uint8_t acc)
{
  int i;
  uint16_t checkSum = 0;

  txBuffer[0] = 0xFA;       //帧头
  txBuffer[1] = slaveAddr;  //从机地址
  txBuffer[2] = 0xF6;       //功能码
  txBuffer[3] = (dir<<7) | ((speed>>8)&0x0F); //方向和速度高4位
  txBuffer[4] = speed&0x00FF;   //速度低8位
  txBuffer[5] = acc;            //加速度
  txBuffer[6] = getCheckSum(txBuffer,6);  //计算校验和

  Serial.write(txBuffer,7);
}

/*
功能：计算一组数据的校验和
输入： buffer  待校验数据
       size    待校验数据个数
输出： 校验值      
*/
uint8_t getCheckSum(uint8_t *buffer,uint8_t size)
{
  uint8_t i;
  uint16_t sum=0;
  for(i=0;i<size;i++)
    {
      sum += buffer[i];  //计算累加值
    }
  return(sum&0xFF);     //返回校验和
}

/*
功能：等待下位机应答，设置超时时间为3000ms
输入： len  应答帧的长度
输出：
  运行成功    1
  运行失败    0
  超时无应答  0
*/
uint8_t waitingForACK(uint8_t len)
{
  uint8_t retVal;       //返回值
  unsigned long sTime;  //计时起始时刻
  unsigned long time;  //当前时刻
  uint8_t rxByte;      

  sTime = millis();    //获取当前时刻
  rxCnt = 0;           //接收计数值置0
  while(1)
  {
    if (Serial.available() > 0)     //串口接收到数据
    {
      rxByte = Serial.read();       //读取1字节数据
      if(rxCnt != 0)
      {
        rxBuffer[rxCnt++] = rxByte; //存储数据
      }
      else if(rxByte == 0xFB)       //判断是否帧头
      {
        rxBuffer[rxCnt++] = rxByte;   //存储帧头
      }
    }

    if(rxCnt == len)    //接收完成
    {
      if(rxBuffer[len-1] == getCheckSum(rxBuffer,len-1))
      {
        retVal = rxBuffer[3];   //校验正确
        break;                  //退出while(1)
      }
      else
      {
        rxCnt = 0;  //校验错误，重新接收应答
      }
    }

    time = millis();
    if((time - sTime) > 3000)   //判断是否超时
    {
      retVal = 0;
      break;                    //超时，退出while(1)
    }
  }
  return(retVal);
}
