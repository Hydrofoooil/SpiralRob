/**************** MKS SERVOxxD闭环步进电机 ***************
******************** arduino系列实验14 ********************
**	实验名称：电机位置模式3—_按绝对坐标运行
**  实验目的：通过串口控制电机按绝对坐标运行
**  实验现象：程序运行后，可观察到
** 1. 电机运行到绝对坐标（absoluteAxis=0），停止2000ms； 
** 2. 电机运行到绝对坐标（absoluteAxis=163840），停止2000ms；；
** 3. 不停循环运行；
** 4. 如果运行失败，LED灯快闪.；
**  注意事项：
** 1. 串口和USB下载口共用串口（0,1），USB上传程序时，先拔掉串口线，以免程序上传失败；
** 2. 电机工作模式设置为SR_vFOC，;
** 3. 如果程序上传失败，可以尝试：按住UNO的RESET按键，再点击上传，待arduino显示“正在上传”时，迅速松开按键；
** 其他资源：
**  CSDN博客：https://blog.csdn.net/gjy_skyblue
**  B站视频：https://space.bilibili.com/393688975/channel/series
**  百度网盘：https://pan.baidu.com/s/1BjrK9SC8pWnDoU32F8jHqA?pwd=mks2
**	QQ技术群：948665794							
**********************************************************/

uint8_t txBuffer[20];      //上位机发送数据数组
uint8_t rxBuffer[20];      //上位机接收数据数组
uint8_t rxCnt=0;          //接收数据计数

int32_t absoluteAxis = 163840;           //绝对坐标 

uint8_t getCheckSum(uint8_t *buffer,uint8_t len);
void positionMode3Run(uint8_t slaveAddr,uint16_t speed,uint8_t acc,int32_t absoluteAxis);
uint8_t waitingForACK(uint32_t delayTime);

void setup() {
  // 设置LED灯端口为输出
  pinMode(LED_BUILTIN, OUTPUT);
  // 启动串口，设置速率38400
  Serial.begin(38400);
  while (!Serial) {
    ; // wait for serial port to connect. Needed for native USB port only
  }
  delay(3000);
}

void loop() {

  uint8_t ackStatus;
  
  positionMode3Run(1,100,200,absoluteAxis); //从机地址=1，转速=100RPM，加速度=200，绝对坐标

  ackStatus = waitingForACK(3000);      //等待位置控制开始应答
  if(ackStatus == 1)                    //位置控制开始
  {
    ackStatus = waitingForACK(0);     //等待位置控制完成应答
    if(ackStatus == 2)                //收到位置控制完成应答
    {
      if(absoluteAxis == 0) absoluteAxis = 163840;    //设定绝对坐标
      else absoluteAxis = 0;
      
    }
    else                        //未收到位置完成应答  
    {
      while(1)                //闪灯提示失败
      {
        digitalWrite(LED_BUILTIN, HIGH);     delay(500);
        digitalWrite(LED_BUILTIN, LOW);      delay(500);
      }
    }
  }
  else                      //位置控制失败
  {
    while(1)                //闪灯提示失败
    {
      digitalWrite(LED_BUILTIN, HIGH);     delay(200);
      digitalWrite(LED_BUILTIN, LOW);      delay(200);
    }
  }

  delay(2000);    //延时2000毫秒
}

/*
功能：串口发送位置模式3运行指令
输入：slaveAddr 从机地址
      speed     运行速度
      acc       加速度
      absAxis   绝对坐标
*/
void positionMode3Run(uint8_t slaveAddr,uint16_t speed,uint8_t acc,int32_t absAxis)
{
  int i;
  uint16_t checkSum = 0;

  txBuffer[0] = 0xFA;       //帧头
  txBuffer[1] = slaveAddr;  //从机地址
  txBuffer[2] = 0xF5;       //功能码
  txBuffer[3] = (speed>>8)&0x00FF; //速度高8位
  txBuffer[4] = speed&0x00FF;     //速度低8位
  txBuffer[5] = acc;            //加速度
  txBuffer[6] = (absAxis >> 24)&0xFF;  //绝对坐标 bit31 - bit24
  txBuffer[7] = (absAxis >> 16)&0xFF;  //绝对坐标 bit23 - bit16
  txBuffer[8] = (absAxis >> 8)&0xFF;   //绝对坐标 bit15 - bit8
  txBuffer[9] = (absAxis >> 0)&0xFF;   //绝对坐标 bit7 - bit0
  txBuffer[10] = getCheckSum(txBuffer,10);  //计算校验和

  Serial.write(txBuffer,11);
}

/*
功能：计算一组数据的校验和
输入： buffer  待校验数据
       size    待校验数据个数
输出： 校验值      
*/
uint8_t getCheckSum(uint8_t *buffer,uint8_t size)
{
  uint8_t i;
  uint16_t sum=0;
  for(i=0;i<size;i++)
    {
      sum += buffer[i];  //计算累加值
    }
  return(sum&0xFF);     //返回校验和
}

/*
功能：等待下位机应答，设置超时时间为3000ms
输入：
  delayTime 等待时间(ms), 
  delayTime = 0 ,无限等待
输出：
  位置模式2控制开始    1
  位置模式2控制完成    2
  位置模式2控制失败    0
  超时无应答           0
*/
uint8_t waitingForACK(uint32_t delayTime)
{
  uint8_t retVal;       //返回值
  unsigned long sTime;  //计时起始时刻
  unsigned long time;  //当前时刻
  uint8_t rxByte;      

  sTime = millis();    //获取当前时刻
  rxCnt = 0;           //接收计数值置0
  while(1)
  {
    if (Serial.available() > 0)     //串口接收到数据
    {
      rxByte = Serial.read();       //读取1字节数据
      if(rxCnt != 0)
      {
        rxBuffer[rxCnt++] = rxByte; //存储数据
      }
      else if(rxByte == 0xFB)       //判断是否帧头
      {
        rxBuffer[rxCnt++] = rxByte;   //存储帧头
      }
    }

    if(rxCnt == 5)    //接收完成
    {
      if(rxBuffer[4] == getCheckSum(rxBuffer,4))
      {
        retVal = rxBuffer[3];   //校验正确
        break;                  //退出while(1)
      }
      else
      {
        rxCnt = 0;  //校验错误，重新接收应答
      }
    }

    time = millis();
    if((delayTime != 0) && ((time - sTime) > delayTime))   //判断是否超时
    {
      retVal = 0;
      break;                    //超时，退出while(1)
    }
  }
  return(retVal);
}
