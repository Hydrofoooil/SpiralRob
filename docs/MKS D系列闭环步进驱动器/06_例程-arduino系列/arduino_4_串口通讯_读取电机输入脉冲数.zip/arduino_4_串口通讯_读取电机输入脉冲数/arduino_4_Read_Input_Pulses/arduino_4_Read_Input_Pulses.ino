/**************** MKS SERVOxxD闭环步进电机 ***************
******************** arduino系列实验4 ********************
**	实验名称：读取输入脉冲数
**  实验目的：通过串口读取输入脉冲数
**  实验现象：程序运行后，可观察到
** 1. 电机匀速运行，每10秒改变一次转速（通过定时器1中断实现）；
** 2. LED灯每秒闪烁一次，即串口发出读取脉冲数指令；
** 3. 串口监视器可以观察到每秒输出一个位置值 pulses = xxxx 。
**  注意事项：
** 1. 串口和USB下载口共用串口（0,1），USB上传程序时，先拔掉串口线，以免程序上传失败；
** 2. 电机工作模式设置为CR_vFOC，;
** 3. 程序下载后，打开串口监视器观察输出结果（工具->串口监视器，波特率选择38400）；
** 4. 如果程序上传失败，可以尝试：按住UNO的RESET按键，再点击上传，待arduino显示“正在上传”时，迅速松开按键；
** 其他资源：
**  CSDN博客：https://blog.csdn.net/gjy_skyblue
**  B站视频：https://space.bilibili.com/393688975/channel/series
**  百度网盘：https://pan.baidu.com/s/1BjrK9SC8pWnDoU32F8jHqA?pwd=mks2
**	QQ技术群：948665794							
**********************************************************/

int EN_PIN = 10;     //定义使能信号端口
int STP_PIN = 9;    //定义脉冲信号端口
int DIR_PIN = 8;    //定义方向信号端口

 uint8_t txBuffer[20];      //发送数据数组
 uint8_t rxBuffer[20];      //接收数据数组
uint8_t rxCnt=0;          //接收数据计数

uint8_t getCheckSum(uint8_t *buffer,uint8_t len);
void readInputPulses(uint8_t slaveAddr);
bool waitingForACK(uint8_t len);
void printToMonitor(uint8_t *value);

#define  TIM_COUNTER1   62536
#define  TIM_COUNTER2   64036
int timer1_counter;
uint32_t loop_cnt = 0;
 

// 定时器1 溢出中断
ISR(TIMER1_OVF_vect)
{
  TCNT1 = timer1_counter;
  digitalWrite(STP_PIN,digitalRead(STP_PIN)^1); //脉冲信号翻转
}

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);// 设置LED灯端口为输出
  pinMode(EN_PIN, OUTPUT);    //设置使能信号端口为输出模式
  pinMode(STP_PIN, OUTPUT);   //设置脉冲信号端口为输出模式
  pinMode(DIR_PIN, OUTPUT);   //设置方向信号端口为输出模式

  // 启动串口，设置速率38400
  Serial.begin(38400);
  //等待串口初始化完成
  while (!Serial) {
    ; // wait for serial port to connect. Needed for native USB port only
  }

// 上电延时5000毫秒，等待电机初始化完毕
  delay(5000);
  digitalWrite(EN_PIN, LOW);  //使能电机
  digitalWrite(DIR_PIN, HIGH); //输出方向信号

  //初始化定时器1中断
  noInterrupts();   //禁止中断
  TCCR1A = 0;
  TCCR1B = 0;

/*如得到xHz的中断频率，则timer1_counter = 65536-(16000000/xHz)
** timer1_counter   中断频率    转速
** 62536                        48RPM
** 64036                        96RPM
*/
  timer1_counter = TIM_COUNTER1;  //timer1 中断频率为5333Hz  
  TCNT1 = timer1_counter;   //预加载timer1
  TCCR1B |= (1<<CS10);    //预分频=1
  TIMSK1 |= (1<<TOIE1);   //允许定时器溢出中断
  interrupts();           //允许中断

 }

void loop() {

  bool ackStatus;
  
  digitalWrite(LED_BUILTIN, HIGH); //亮灯
  readInputPulses(1); //从机地址=1，发出查询脉冲数指令

  ackStatus = waitingForACK(8);      //等待电机应答

  if(ackStatus == true)        //接收到脉冲数
  {
    printToMonitor(&rxBuffer[3]); // 脉冲数输出到串口监视器
    digitalWrite(LED_BUILTIN, LOW); //灭灯
    
  }
  else                      //接收脉冲数信息失败（1.检查串口线连接；2.检查电机是否上电；3.检查从机地址，波特率）
  {
    while(1)                //快速闪灯，提示运行失败
    {
      digitalWrite(EN_PIN, HIGH);  //释放电机
      digitalWrite(LED_BUILTIN, HIGH);
      delay(200);
      digitalWrite(LED_BUILTIN, LOW);
      delay(200);
    }
  }

  loop_cnt++;
  if(loop_cnt == 10) //每10秒改变一次转速
  {
    loop_cnt = 0;
    timer1_counter += 100;
    if(timer1_counter > TIM_COUNTER2)
    {
      timer1_counter = TIM_COUNTER1;
    }
  }  
  
  delay(1000);    //延时1000毫秒
}

/*
功能：读取输入脉冲数
输入：slaveAddr 从机地址
输出：无
 */
void readInputPulses(uint8_t slaveAddr)
{
 
  txBuffer[0] = 0xFA;       //帧头
  txBuffer[1] = slaveAddr;  //从机地址
  txBuffer[2] = 0x33;       //功能码
  txBuffer[3] = getCheckSum(txBuffer,3);  //计算校验和
  Serial.write(txBuffer,4);   //串口发出读取输入脉冲数指令
}

/*
功能：计算一组数据的校验和
输入： buffer  待校验数据
       size    待校验数据个数
输出： 校验值      
*/
uint8_t getCheckSum(uint8_t *buffer,uint8_t size)
{
  uint8_t i;
  uint16_t sum=0;
  for(i=0;i<size;i++)
    {
      sum += buffer[i];  //计算累加值
    }
  return(sum&0xFF);     //返回校验和
}

/*
功能：等待从机应答，设置超时时间为3000ms
输入： len  应答帧的长度
输出：
  运行成功    true
  运行失败    false
  超时无应答  false
*/
bool waitingForACK(uint8_t len)
{
  bool retVal;       //返回值
  unsigned long sTime;  //计时起始时刻
  unsigned long time;  //当前时刻
  uint8_t rxByte;      

  sTime = millis();    //获取当前时刻
  rxCnt = 0;           //接收计数值置0
  while(1)
  {
    if (Serial.available() > 0)     //串口接收到数据
    {
      rxByte = Serial.read();       //读取1字节数据
      if(rxCnt != 0)
      {
        rxBuffer[rxCnt++] = rxByte; //存储数据
      }
      else if(rxByte == 0xFB)       //判断是否帧头
      {
        rxCnt = 0;
        rxBuffer[rxCnt++] = rxByte;   //存储帧头
      }
    }

    if(rxCnt == len)    //接收完成
    {
      if(rxBuffer[len-1] == getCheckSum(rxBuffer,len-1))
      {
        retVal = true;   //校验正确
        break;                  //退出while(1)
      }
      else
      {
        rxCnt = 0;  //校验错误，重新接收应答
      }
    }

    time = millis();
    if((time - sTime) > 3000)   //判断是否超时
    {
      retVal = false;
      break;                    //超时，退出while(1)
    }
  }
  return(retVal);
}

/*
功能：将脉冲数输出到串口监视器
      1.工具->串口监视器
      2.波特率选择38400
      3.可以观察到每秒输出一个脉冲数 pulses = xxxx 
输入：*value 脉冲数起始地址
输出：无
*/
void printToMonitor(uint8_t *value)
{
  int32_t iValue;
  String  tStr;
  iValue = (int32_t)(
                      ((uint32_t)value[0] << 24)    |
                      ((uint32_t)value[1] << 16)    |
                      ((uint32_t)value[2] << 8)     |
                      ((uint32_t)value[3] << 0)
                    );

  
  tStr = String(iValue);
  Serial.print("  pulses = ");
  Serial.println(tStr);
 }
