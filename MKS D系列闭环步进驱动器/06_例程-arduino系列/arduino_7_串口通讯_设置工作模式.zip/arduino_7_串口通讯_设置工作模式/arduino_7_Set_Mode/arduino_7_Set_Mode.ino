/**************** MKS SERVOxxD闭环步进电机 ***************
******************** arduino系列实验7 ********************
**	实验名称：设置电机工作模式
**  实验目的：通过串口设置工作模式
**  实验现象：程序运行后，可观察到
** 1. LED灯亮，即串口发出设置细分指令；
** 2. 如果设置成功，LED灯慢闪，可通过屏幕菜单Mode选项，查看设置的工作模式；
** 3. 如果设置失败，LED灯快闪.
**  注意事项：
** 1. 串口和USB下载口共用串口（0,1），USB上传程序时，先拔掉串口线，以免程序上传失败；
** 2. 电机工作模式设置为CR_vFOC，;
** 3. 如果程序上传失败，可以尝试：按住UNO的RESET按键，再点击上传，待arduino显示“正在上传”时，迅速松开按键；
** 其他资源：
**  CSDN博客：https://blog.csdn.net/gjy_skyblue
**  B站视频：https://space.bilibili.com/393688975/channel/series
**  百度网盘：https://pan.baidu.com/s/1BjrK9SC8pWnDoU32F8jHqA?pwd=mks2
**	QQ技术群：948665794							
**********************************************************/

uint8_t txBuffer[20];      //发送数据数组
uint8_t rxBuffer[20];      //接收数据数组
uint8_t rxCnt=0;          //接收数据计数

uint8_t getCheckSum(uint8_t *buffer,uint8_t len);
void setMode(uint8_t slaveAddr,uint8_t Mode);
uint8_t waitingForACK(uint8_t len);


void setup() {
  pinMode(LED_BUILTIN, OUTPUT);// 设置LED灯端口为输出
  digitalWrite(LED_BUILTIN, HIGH); //灭灯

  // 启动串口，设置速率38400
  Serial.begin(38400);
  //等待串口初始化完成
  while (!Serial) {
    ; // wait for serial port to connect. Needed for native USB port only
  }

// 上电延时3000毫秒，等待电机初始化完毕
  delay(3000);
  }

void loop() {

  bool ackStatus;
  
  digitalWrite(LED_BUILTIN, HIGH); //亮灯
  setMode(1,5); //从机地址=1，mode =5 (SR_vFOC)

  ackStatus = waitingForACK(5);      //等待电机应答

  if(ackStatus == 1)        //设置成功
  {
    while(1)    //慢速闪灯，提示设置成功 （可在屏幕菜单Mode选项，查看设置的工作模式）
    {
      digitalWrite(LED_BUILTIN, HIGH); delay(1000);    //延时1000毫秒
      digitalWrite(LED_BUILTIN, LOW);  delay(1000);    //延时1000毫秒
    }
  }
  else          //设置失败（1.检查串口线连接；2.检查电机是否上电；3.检查从机地址，波特率）
  {
    while(1)   //快速闪灯，提示设置失败
    {
      digitalWrite(LED_BUILTIN, HIGH);      delay(200);
      digitalWrite(LED_BUILTIN, LOW);      delay(200);
    }
  }
 
}

/*
功能：设置工作模式
输入：slaveAddr 从机地址
      Mode 工作模式
输出：无
 */
void setMode(uint8_t slaveAddr,uint8_t Mode)
{
 
  txBuffer[0] = 0xFA;       //帧头
  txBuffer[1] = slaveAddr;  //从机地址
  txBuffer[2] = 0x82;       //功能码
  txBuffer[3] = Mode;       //工作模式
  txBuffer[4] = getCheckSum(txBuffer,4);  //计算校验和
  Serial.write(txBuffer,5);   //串口发出指令
}

/*
功能：计算一组数据的校验和
输入： buffer  待校验数据
       size    待校验数据个数
输出： 校验值      
*/
uint8_t getCheckSum(uint8_t *buffer,uint8_t size)
{
  uint8_t i;
  uint16_t sum=0;
  for(i=0;i<size;i++)
    {
      sum += buffer[i];  //计算累加值
    }
  return(sum&0xFF);     //返回校验和
}

/*
功能：等待从机应答，设置超时时间为3000ms
输入： len  应答帧的长度
输出：
  运行成功    1
  运行失败    0
  超时无应答  0
*/
uint8_t waitingForACK(uint8_t len)
{
  uint8_t retVal=0;       //返回值
  unsigned long sTime;  //计时起始时刻
  unsigned long time;  //当前时刻
  uint8_t rxByte;      

  sTime = millis();    //获取当前时刻
  rxCnt = 0;           //接收计数值置0
  while(1)
  {
    if (Serial.available() > 0)     //串口接收到数据
    {
      rxByte = Serial.read();       //读取1字节数据
      if(rxCnt != 0)
      {
        rxBuffer[rxCnt++] = rxByte; //存储数据
      }
      else if(rxByte == 0xFB)       //判断是否帧头
      {
        rxBuffer[rxCnt++] = rxByte;   //存储帧头
      }
    }

    if(rxCnt == len)    //接收完成
    {
      if(rxBuffer[len-1] == getCheckSum(rxBuffer,len-1))
      {
        retVal = rxBuffer[3];   //校验正确
        break;                  //退出while(1)
      }
      else
      {
        rxCnt = 0;  //校验错误，重新接收应答
      }
    }

    time = millis();
    if((time - sTime) > 3000)   //判断是否超时
    {
      retVal = 0;
      break;                    //超时，退出while(1)
    }
  }
  return(retVal);
}

