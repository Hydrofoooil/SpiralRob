/**************** MKS SERVOxxD闭环步进电机 ***************
******************** arduino系列实验6 ********************
**	实验名称：读取IO端口状态
**  实验目的：通过串口读取IO端口状态
**  实验现象：程序运行后，可观察到
** 1. LED灯每秒闪烁一次，即串口发出读取脉冲数指令；
** 2. 串口监视器可以观察到每秒输出一个IO状态 IN_1=x  IN_2=x  OUT_1=x  OUT_2=x
** 3. 改变输入端口状态（比如IN_1端口接地），可以观察到输出IO状态也会跟着变化
**  注意事项：
** 1. 串口和USB下载口共用串口（0,1），USB上传程序时，先拔掉串口线，以免程序上传失败；
** 2. 电机工作模式设置为CR_vFOC，;
** 3. 程序下载后，打开串口监视器观察输出结果（工具->串口监视器，波特率选择38400）；
** 4. 如果程序上传失败，可以尝试：按住UNO的RESET按键，再点击上传，待arduino显示“正在上传”时，迅速松开按键；
** 其他资源：
**  CSDN博客：https://blog.csdn.net/gjy_skyblue
**  B站视频：https://space.bilibili.com/393688975/channel/series
**  百度网盘：https://pan.baidu.com/s/1BjrK9SC8pWnDoU32F8jHqA?pwd=mks2
**	QQ技术群：948665794							
**********************************************************/

uint8_t txBuffer[20];      //发送数据数组
uint8_t rxBuffer[20];      //接收数据数组
uint8_t rxCnt=0;          //接收数据计数

uint8_t getCheckSum(uint8_t *buffer,uint8_t len);
void readIOStatus(uint8_t slaveAddr);
bool waitingForACK(uint8_t len);
void printToMonitor(uint8_t *value);

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);// 设置LED灯端口为输出

  // 启动串口，设置速率38400
  Serial.begin(38400);
  //等待串口初始化完成
  while (!Serial) {
    ; // wait for serial port to connect. Needed for native USB port only
  }

// 上电延时5000毫秒，等待电机初始化完毕
  delay(5000);
  }

void loop() {

  bool ackStatus;
  
  digitalWrite(LED_BUILTIN, HIGH); //亮灯
  readIOStatus(1); //从机地址=1，发出查询IO端口状态指令

  ackStatus = waitingForACK(5);      //等待电机应答

  if(ackStatus == true)        //接收到IO端口状态
  {
    printToMonitor(&rxBuffer[3]); // IO端口状态输出到串口监视器
    digitalWrite(LED_BUILTIN, LOW); //灭灯
    
  }
  else                      //接收IO端口状态信息失败（1.检查串口线连接；2.检查电机是否上电；3.检查从机地址，波特率）
  {
    while(1)                //快速闪灯，提示运行失败
    {
      digitalWrite(LED_BUILTIN, HIGH);
      delay(200);
      digitalWrite(LED_BUILTIN, LOW);
      delay(200);
    }
  }

  delay(1000);    //延时1000毫秒
}

/*
功能：读取输入脉冲数
输入：slaveAddr 从机地址
输出：无
 */
void readIOStatus(uint8_t slaveAddr)
{
 
  txBuffer[0] = 0xFA;       //帧头
  txBuffer[1] = slaveAddr;  //从机地址
  txBuffer[2] = 0x34;       //功能码
  txBuffer[3] = getCheckSum(txBuffer,3);  //计算校验和
  Serial.write(txBuffer,4);   //串口发出读取输入脉冲数指令
}

/*
功能：计算一组数据的校验和
输入： buffer  待校验数据
       size    待校验数据个数
输出： 校验值      
*/
uint8_t getCheckSum(uint8_t *buffer,uint8_t size)
{
  uint8_t i;
  uint16_t sum=0;
  for(i=0;i<size;i++)
    {
      sum += buffer[i];  //计算累加值
    }
  return(sum&0xFF);     //返回校验和
}

/*
功能：等待从机应答，设置超时时间为3000ms
输入： len  应答帧的长度
输出：
  运行成功    true
  运行失败    false
  超时无应答  false
*/
bool waitingForACK(uint8_t len)
{
  bool retVal;       //返回值
  unsigned long sTime;  //计时起始时刻
  unsigned long time;  //当前时刻
  uint8_t rxByte;      

  sTime = millis();    //获取当前时刻
  rxCnt = 0;           //接收计数值置0
  while(1)
  {
    if (Serial.available() > 0)     //串口接收到数据
    {
      rxByte = Serial.read();       //读取1字节数据
      if(rxCnt != 0)
      {
        rxBuffer[rxCnt++] = rxByte; //存储数据
      }
      else if(rxByte == 0xFB)       //判断是否帧头
      {
        rxBuffer[rxCnt++] = rxByte;   //存储帧头
      }
    }

    if(rxCnt == len)    //接收完成
    {
      if(rxBuffer[len-1] == getCheckSum(rxBuffer,len-1))
      {
        retVal = true;   //校验正确
        break;                  //退出while(1)
      }
      else
      {
        rxCnt = 0;  //校验错误，重新接收应答
      }
    }

    time = millis();
    if((time - sTime) > 3000)   //判断是否超时
    {
      retVal = false;
      break;                    //超时，退出while(1)
    }
  }
  return(retVal);
}

/*
功能：将IO端口状态结果输出到串口监视器
      1.工具->串口监视器
      2.波特率选择38400
      3.可以观察到每秒输出一个IO端口状态  
输入：*value IO端口状态起始地址
输出：无
*/
void printToMonitor(uint8_t *value)
{
  uint8_t iValue;
  iValue = value[0]&1;   
  Serial.print("  IN_1 = ");
  Serial.print(iValue);

  iValue = (value[0]&2)>>1;   
  Serial.print("  IN_2 = ");
  Serial.print(iValue);

  iValue = (value[0]&4)>>2;   
  Serial.print("  OUT_1 = ");
  Serial.print(iValue);

  iValue = (value[0]&8)>>3;   
  Serial.print("  OUT_2 = ");
  Serial.println(iValue);
 }
