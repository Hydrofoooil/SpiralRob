/**************** MKS SERVOxxD闭环步进电机 ***************
******************** arduino系列实验2 ********************
**	实验名称：读取电机实时位置信息
**  实验目的：通过串口读取电机实时位置信息
**  实验现象：程序运行后，可观察到
** 1. LED灯每秒闪烁一次，即串口发出读取实时位置指令；
** 2. 串口监视器可以观察到每秒输出一个位置值 value = xxxxx；
** 3. 手转动电机轴，可以看到位置值变化 (增加或减少)。
**  注意事项：
** 1. 串口和USB下载口共用串口（0,1），USB上传程序时，先拔掉串口线，以免程序上传失败；
** 2. 电机工作模式设置为CR_vFOC，不要使能电机(手可转动电机轴);
** 3. 程序下载后，打开串口监视器观察输出结果（工具->串口监视器，波特率选择38400）；
** 4. 电机轴每转动一圈（360度），位置值变化（加/减）16384；
** 5. 如果程序上传失败，可以尝试：按住UNO的RESET按键，再点击上传，待arduino显示“正在上传”时，迅速松开按键；
** 其他资源：
**  CSDN博客：https://blog.csdn.net/gjy_skyblue
**  B站视频：https://space.bilibili.com/393688975/channel/series
**  百度网盘：https://pan.baidu.com/s/1BjrK9SC8pWnDoU32F8jHqA?pwd=mks2
**	QQ技术群：948665794							
**********************************************************/
 
uint8_t txBuffer[20];      //发送数据数组
uint8_t rxBuffer[20];      //接收数据数组
uint8_t rxCnt=0;          //接收数据计数

uint8_t getCheckSum(uint8_t *buffer,uint8_t len);
void readRealTimeLocation(uint8_t slaveAddr);
bool waitingForACK(uint8_t len);
void printToMonitor(uint8_t *value);

void setup() {
  // 设置LED灯端口为输出
  pinMode(LED_BUILTIN, OUTPUT);
  // 启动串口，设置速率38400
  Serial.begin(38400);
  //等待串口初始化完成
  while (!Serial) {
    ; // wait for serial port to connect. Needed for native USB port only
  }
  // 上电延时3000毫秒，等待电机初始化完毕
  delay(3000);
}

void loop() {

  bool ackStatus;
  
  digitalWrite(LED_BUILTIN, HIGH); //亮灯
  readRealTimeLocation(1); //从机地址=1，发出查询位置信息指令

  ackStatus = waitingForACK(10);      //等待电机应答

  if(ackStatus == true)        //接收到位置信息
  {
    printToMonitor(&rxBuffer[5]); // 低32位 实时位置值输出到串口监视器
    digitalWrite(LED_BUILTIN, LOW); //灭灯
    
  }
  else                      //接收位置信息失败（1.检查串口线连接；2.检查电机是否上电；3.检查从机地址，波特率）
  {
    while(1)                //快速闪灯，提示运行失败
    {
      digitalWrite(LED_BUILTIN, HIGH);
      delay(200);
      digitalWrite(LED_BUILTIN, LOW);
      delay(200);
    }
  }

  delay(3000);    //延时3000毫秒
}

/*
功能：读取实时位置信息
输入：slaveAddr 从机地址
输出：无
 */
void readRealTimeLocation(uint8_t slaveAddr)
{
 
  txBuffer[0] = 0xFA;       //帧头
  txBuffer[1] = slaveAddr;  //从机地址
  txBuffer[2] = 0x31;       //功能码
  txBuffer[3] = getCheckSum(txBuffer,3);  //计算校验和
  Serial.write(txBuffer,4);   //串口发出读取实时位置指令
}

/*
功能：计算一组数据的校验和
输入： buffer  待校验数据
       size    待校验数据个数
输出： 校验值      
*/
uint8_t getCheckSum(uint8_t *buffer,uint8_t size)
{
  uint8_t i;
  uint16_t sum=0;
  for(i=0;i<size;i++)
    {
      sum += buffer[i];  //计算累加值
    }
  return(sum&0xFF);     //返回校验和
}

/*
功能：等待从机应答，设置超时时间为3000ms
输入： len  应答帧的长度
输出：
  运行成功    true
  运行失败    false
  超时无应答  false
*/
bool waitingForACK(uint8_t len)
{
  bool retVal;       //返回值
  unsigned long sTime;  //计时起始时刻
  unsigned long time;  //当前时刻
  uint8_t rxByte;      

  sTime = millis();    //获取当前时刻
  rxCnt = 0;           //接收计数值置0
  while(1)
  {
    if (Serial.available() > 0)     //串口接收到数据
    {
      rxByte = Serial.read();       //读取1字节数据
      if(rxCnt != 0)
      {
        rxBuffer[rxCnt++] = rxByte; //存储数据
      }
      else if(rxByte == 0xFB)       //判断是否帧头
      {
        rxBuffer[rxCnt++] = rxByte;   //存储帧头
      }
    }

    if(rxCnt == len)    //接收完成
    {
      if(rxBuffer[len-1] == getCheckSum(rxBuffer,len-1))
      {
        retVal = true;   //校验正确
        break;                  //退出while(1)
      }
      else
      {
        rxCnt = 0;  //校验错误，重新接收应答
      }
    }

    time = millis();
    if((time - sTime) > 3000)   //判断是否超时
    {
      retVal = false;
      break;                    //超时，退出while(1)
    }
  }
  return(retVal);
}

/*
功能：将实时位置的低32位结果输出到串口监视器
      1.工具->串口监视器
      2.波特率选择38400
      3.可以观察到每秒输出一个位置值 value = xxxxx
      4.手转动电机轴，可以看到位置值变化 ，电机轴转动一圈，位置值变化(增加或减少)16384
输入：*value 位置值低32位起始地址
输出：无
*/
void printToMonitor(uint8_t *value)
{
  int32_t iValue;
  String  tStr;
  iValue = (int32_t)(
                      ((uint32_t)value[0] << 24)    |
                      ((uint32_t)value[1] << 16)    |
                      ((uint32_t)value[2] << 8)     |
                      ((uint32_t)value[3] << 0)
                    );

  
  tStr = String(iValue);
  Serial.print("  location = ");
  Serial.println(tStr);
/*
  int32_t iValue;
  iValue = value[0]<<24 | value[1]<<16 | value[2]<<8 | value[3]<<0;
  
  Serial.print("value = ");
  Serial.println(iValue);
*/

}
